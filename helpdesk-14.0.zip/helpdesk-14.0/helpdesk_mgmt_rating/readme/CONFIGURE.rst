To configure this module, you need to:

#. Edit or create stages.
#. Edit or create tickets.

Stages
~~~~~~
#. Go to *Helpdesk > Configuration > Stages* to edit or create new stages.
#. Edit or create a new stage.
#. Set the name for the stage.
#. You can select the Email template for rating.

Tickets
~~~~~~~
#. Go to *Helpdesk > Ticket* to edit or create new tickets.
#. Edit or create a new ticket.
#. Set the name for the ticket.
#. Select if the ticket should be qualified or not.
