* Go to Helpdesk > Configuration > Types
* Create your list of types
