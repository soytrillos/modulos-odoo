* `Aresoltec Canarias, S.L <https://www.aresoltec.com>`_:

  * Inma Sánchez

* `SDi Soluciones, S.L. <https://www.sdi.es>`_:

  * Oscar Soto
  * Jorge Luis Quinteros

* `Punt Sistemes, S.L. <https://www.puntsistemes.es/>`_:

  * Carlos Ramos

* `Solvos Consultoría Informática, S.L. <https://www.solvos.es/>`_:

  * David Alonso

* `Guadaltech Soluciones Tecnológicas, S.L. <https://www.guadaltech.es/>`_:

  * Fernando La Chica <fernandolachica@gmail.com>
