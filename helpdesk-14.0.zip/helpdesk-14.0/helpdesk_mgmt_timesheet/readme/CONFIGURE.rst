To configure this module, you need to:

#. Allow Timesheet for a Helpdesk's Team
#. Set a Default Project (optional)

Allow Timesheet
~~~~~~~~~~~~~~~

#. Go to Helpdesk > Configuration > Teams.
#. Edit or create a new team.
#. Check Allow Timesheet option to allow timesheets for that team.
#. Select a Project for that team (optional).
