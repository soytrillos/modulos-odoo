# Copyright (C) 2019 Open Source Integrators
# Copyright (C) 2019 Konos
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
from . import helpdesk_ticket
from . import helpdesk_ticket_team
from . import helpdesk_ticket_motive
