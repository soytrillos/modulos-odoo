#. Go to *Customers > (select one of your choice) > Sales & Purchases*.
#. Set *Valued picking* field on.
