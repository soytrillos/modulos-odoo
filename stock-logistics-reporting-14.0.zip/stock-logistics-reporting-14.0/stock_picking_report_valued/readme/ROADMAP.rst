* If the picking is not reserved, values aren't computed.
