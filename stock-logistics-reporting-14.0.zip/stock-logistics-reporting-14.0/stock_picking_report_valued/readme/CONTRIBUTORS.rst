* `Avanzosc <http://www.avanzosc.es>`_:

  * Oihane Crucelaegui

* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Antonio Espinosa
  * Carlos Dauden
  * David Vidal
  * Luis M. Ontalba
  * Ernesto Tejeda
  * Sergio Teruel
