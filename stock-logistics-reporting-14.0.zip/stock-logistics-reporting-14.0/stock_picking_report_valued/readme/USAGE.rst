To get the stock picking valued report:

#. Create a Sales Order with storable products a *Valued picking* able
   customer.
#. Confirm the Sale Order.
#. Click on *Delivery* stat button.
#. Go to *Print > Delivery Slip*.
