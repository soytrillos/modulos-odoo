from . import test_stock_picking_valued
