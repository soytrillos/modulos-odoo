This is a glue module for the sale line position on the delivery report
and the module `stock_picking_group_by_partner_by_carrier`.

It ensures that on the delivery report the position column is displayed
only if some positions exist.
And also adds the sale line position on the remaining to deliver list at
the bottom of the report.
