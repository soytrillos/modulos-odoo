This module is build on top of the module `sale_order_line_position`.

On the delivery report it adds a column with the `Postion` from the related
sale order line.

The `Position` can also made visible int the stock picking view.
