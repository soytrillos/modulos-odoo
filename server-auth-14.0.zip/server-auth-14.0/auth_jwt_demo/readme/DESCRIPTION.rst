A test/demo module for ``auth_jwt``.
