This module extends the functionality of users module to support loging in
with an extra system administrator password in other user accounts.

* System Administrator has now the possibility to login in with any login

* According to the configuration, Odoo will send a mail to user and admin to
  indicate them
