* Holger Brunn <hbrunn@therp.nl>
* Giacomo Spettoli <giacomo.spettoli@gmail.com>
* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>
* Tecnativa <https://www.tecnativa.com>

  * João Marques
* Dhara Solanki <dhara.solanki@initos.com>
