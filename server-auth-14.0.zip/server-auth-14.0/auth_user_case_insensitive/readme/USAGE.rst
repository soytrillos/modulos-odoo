.. image:: https://odoo-community.org/website/image/ir.attachment/5784_f2813bd/datas
   :alt: Steps to test the module
   :target: https://runbot.odoo-community.org/runbot/167/11.0
