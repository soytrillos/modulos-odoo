This module allows to authenticate using a LDAP over SSL system.
