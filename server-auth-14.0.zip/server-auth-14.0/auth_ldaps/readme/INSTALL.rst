To verify LDAPS server certificate, you need to:

#. Add the CA certificate of the LDAPS on your server as a trusted certificate
#. Check the Verify certificate´ flag in configuration
