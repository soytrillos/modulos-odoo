To configure this module, you need to:

#. Access Settings / General Settings / LDAP Authentication / LDAP Server
#. Check the ´Use LDAPS´ flag
