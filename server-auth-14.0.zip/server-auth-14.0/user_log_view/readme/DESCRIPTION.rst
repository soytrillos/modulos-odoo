This module adds a smart button on user's form to display authentication logs.
