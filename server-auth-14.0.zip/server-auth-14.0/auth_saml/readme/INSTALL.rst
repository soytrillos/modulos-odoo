This addon requires ``pysaml2``.

``pysaml2`` requires ``xmlsec1`` (on Ubuntu you can ``apt-get install xmlsec1``)
