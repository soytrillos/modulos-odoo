* Florent Aide <florent.aide@xcg-consulting.fr>
* Vincent Hatakeyama <vincent.hatakeyama@xcg-consulting.fr>
* Alexandre Brun <alexandre.brun@xcg-consulting.fr>
* Jeremy Co Kim Len <jeremy.cokimlen@vinci-concessions.com>
* Houzéfa Abbasbhay <houzefa.abba@xcg-consulting.fr>
* Jeffery Chen Fan <jeffery9@gmail.com>
* Bhavesh Odedra <bodedra@opensourceintegrators.com>
* `Tecnativa <https://www.tecnativa.com/>`__:
  * Jairo Llopis
* `GlodoUK <https://www.glodo.uk/>`__:
  * Karl Southern
* `TAKOBI <https://takobi.online/>`__:
  * Lorenzo Battistini
