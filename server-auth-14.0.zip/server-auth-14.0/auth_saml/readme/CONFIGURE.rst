To use this module, you need an IDP server, properly set up. Go through the

#. Configure the module according to your IDP's instructions
   (Settings > Users & Companies > SAML Providers).
#. Pre-create your users and set the SAML information against the user.
