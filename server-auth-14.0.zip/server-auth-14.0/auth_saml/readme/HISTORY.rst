3.0
~~~

* Migrate from lasso to pysaml2

2.0
~~~

* SAML tokens are not stored in res_users anymore to avoid locks on that table
