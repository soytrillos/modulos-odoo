* James Foster <jfoster@laslabs.com>
* Dave Lasley <dave@laslabs.com>
* Kaushal Prajapati <kbprajapati@live.com>
* Petar Najman <petar.najman@modoolar.com>
* Shepilov Vladislav <shepilov.v@protonmail.com>
* Florian Kantelberg <florian.kantelberg@initos.com>

* `Open Source Integrators <https://opensourceintegrators.com>`_

    * Chandresh Thakkar <cthakkar@opensourceintegrators.com>
    * Daniel Reis <dreis@opensourceintegrators.com>
