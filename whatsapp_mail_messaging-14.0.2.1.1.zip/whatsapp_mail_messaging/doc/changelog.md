## Module <whatsapp_mail_messaging>

#### 14.05.2021
#### Version 14.0.1.0.0
#### ADD
- Initial commit

#### 25.06.2021
#### Version 14.0.2.1.1
#### UPDT
- New Features added




