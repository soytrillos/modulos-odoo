* The UI could get some improvements
* Being able to open the measurement screen from a product would be nice
