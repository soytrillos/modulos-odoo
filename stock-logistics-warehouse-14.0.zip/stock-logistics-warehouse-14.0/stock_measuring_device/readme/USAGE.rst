Use the "Wizard" button on a Measuring Device to open the screen and take
measurements.
