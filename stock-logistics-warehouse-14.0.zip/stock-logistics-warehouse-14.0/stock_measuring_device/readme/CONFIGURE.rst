The first step is to configure the Packaging Types (Pallet, Box, ...) in Inventory > Configuration > Product Packaging Types.

Configure the measuring device in Inventory > Configuration > Measuring
Devices, don't forget to set the device type, and any other additional
parameters.
