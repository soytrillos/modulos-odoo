This module by itself does not do anything.

You will need to install a module implementing the communication with your
device. Look for modules with a name starting with stock_measuring_device.
