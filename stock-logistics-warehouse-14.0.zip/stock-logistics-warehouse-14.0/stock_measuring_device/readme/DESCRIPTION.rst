Different manufacturers produce devices which are able to measure and weigh
packages and parcels. Each brand has a different communication protocol. This
module provides an framework to interface such devices with Odoo.
