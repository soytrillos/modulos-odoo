To use this module, you simply need to:

#. Create a new inventory adjustment.
#. Select the option inventory of all products.
#. Check the box "Exclude Sublocations".
