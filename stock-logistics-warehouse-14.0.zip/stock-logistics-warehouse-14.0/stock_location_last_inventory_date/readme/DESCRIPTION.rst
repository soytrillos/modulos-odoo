Add a stored computed field on locations that states the last inventory date
of the location (only for validated inventories). This is only computed
for leaf locations, not parent ones.
