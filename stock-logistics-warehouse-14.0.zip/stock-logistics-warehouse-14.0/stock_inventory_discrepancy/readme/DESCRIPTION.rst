Adds the capability to show the discrepancy of every line in an inventory and
to block the inventory validation (setting it as 'Pending to Approve') when the
discrepancy is greater than an user defined threshold.

Only new group "Validate All inventory Adjustments" will be able to force the
validation of those blocked inventories. By default, Stock manager will belong
to this group. In addition, Stock Users can validate inventories under the
threshold now.
