From a validated stock adjustment, use action -> Generate putaway per product.

The end result is that the location's putaway strategy will be updated, so that all products (and their locations) from the inventory will show up on the putaway strategy.
