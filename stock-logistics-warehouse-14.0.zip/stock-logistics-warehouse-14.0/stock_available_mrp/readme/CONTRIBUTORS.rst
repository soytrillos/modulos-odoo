* Loïc Bellier (Numérigraphe) <lb@numerigraphe.com>
* Lionel Sausin (Numérigraphe) <ls@numerigraphe.com>
* many thanks to Graeme Gellatly for his advice and code review
* Laurent Mignon <laurent.mignon@acsone.eu>
* Cédric Pigeon <cedric.pigeon@acsone.eu>
* Florian da Costa <florian.dacosta@akretion.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
