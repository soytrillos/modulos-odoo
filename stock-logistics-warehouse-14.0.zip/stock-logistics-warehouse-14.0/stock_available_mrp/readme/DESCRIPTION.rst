This module takes the potential quantities available for Products into account in
the quantity available to promise, where the "Potential quantity" is the
quantity that can be manufactured with the components immediately at hand.
By configuration, the "Potential quantity" can be computed based on other product field.
For example, "Potential quantity" can be the quantity that can be manufactured
with the components available to promise.
