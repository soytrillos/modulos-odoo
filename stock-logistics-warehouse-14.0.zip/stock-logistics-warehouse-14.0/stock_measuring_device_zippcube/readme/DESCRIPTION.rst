Different manufacturers produce devices which are able to measure and weigh
packages and parcels. Each brand has a different communication protocol. This
module provides an framework to interface such devices with Odoo.

This module provides support for Bosche Zippcube devices.


https://www.bosche.eu/en/industrial-scales/logistic-scales/scales-for-logistic-and-transport/zippcube
