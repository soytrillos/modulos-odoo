Use the "Wizard" button on a Measuring Device to open the screen and take
measurements.

After the measurement has been made, you need to click on the Refresh button.
