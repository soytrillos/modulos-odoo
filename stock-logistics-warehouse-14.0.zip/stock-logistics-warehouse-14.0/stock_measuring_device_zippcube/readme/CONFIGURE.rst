Create a measuring device with a type set to "zippcube".
