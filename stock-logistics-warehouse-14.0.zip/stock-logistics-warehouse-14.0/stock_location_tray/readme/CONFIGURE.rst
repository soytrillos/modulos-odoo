General
~~~~~~~

In Inventory Settings, you must have:

 * Storage Locations

Tray types
~~~~~~~~~~

Tray types can be configured in the Inventory settings.
A tray type defines how much cells a tray can hold. It is a square or rectangle
matrix of n cols * m rows.

Locations
~~~~~~~~~

The tray type can be configured in Stock Locations.

The tray type of a tray can be changed as long as none of its cell contains
products. When changed, it archives the cells and creates new ones as configured
on the new tray type.

The matrix widget on Tray locations can be clicked to reach a sub-location.
Blue squares represent the locations that contain goods.
