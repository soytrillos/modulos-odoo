This module adds a `children_ids` field on `stock.location` in order to compute
and store all the children for a `stock.location` and not only its first level
children as is the case for `child_ids`.
