This module allows to create demand estimates for a given product and
location, on configurable time periods.

The module does not provide in itself any specific usage of the estimates.
