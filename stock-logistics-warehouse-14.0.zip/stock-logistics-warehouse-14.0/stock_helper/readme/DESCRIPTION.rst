Add methods to be used by other modules. This is not a functional module.
