Add Product variant free quantity in Product form view and add the same on Product templates.
