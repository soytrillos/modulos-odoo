Allows to block archiving products with associated stock.quant or stock.move.
Allows to block archiving locations with associated stock.quant or stock.move.
