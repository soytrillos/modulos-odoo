#. Go to Settings > Users > Edit a user and check the "Manage Multiple Stock Locations" permission
#. Go to Inventory > Settings > Locations and disable one
