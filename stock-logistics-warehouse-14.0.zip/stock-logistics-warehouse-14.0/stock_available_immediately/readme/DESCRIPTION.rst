Normally the quantity available to promise is based on the virtual stock,
which includes both planned outgoing and incoming goods.
This module will subtract the planned receptions from the quantity available to
promise.
