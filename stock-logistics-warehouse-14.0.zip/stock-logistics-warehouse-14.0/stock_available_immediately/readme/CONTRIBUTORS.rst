* Author: Guewen Baconnier (Camptocamp SA)
* Sébastien BEAU (Akretion) <sebastien.beau@akretion.com>
* Lionel Sausin (Numérigraphe) <ls@numerigraphe.com>
* Sodexis <sodexis@sodexis.com>
* Cédric Pigeon <cedric.pigeon@acsone.eu>
* Sergio Díaz <sergiodm.1989@gmail.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
* Florian da Costa <florian.dacosta@akretion.com>
