This module adds position attributes on stock location such as:

* Corridor
* Row
* Rack
* Level

and renames position (XYZ) to box (XYZ).
