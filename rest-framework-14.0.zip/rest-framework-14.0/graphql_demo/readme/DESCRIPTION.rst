This is a demonstration module providing a sample GraphQL endpoint,
as well as tests for ``graphql_base``.
