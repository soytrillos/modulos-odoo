from .main import GraphQLControllerMixin
