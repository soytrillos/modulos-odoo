This modules enables the creation of `GraphQL <https://graphql.org/>`__ endpoints.
In itself, it does nothing and must be used by a developer to
create the GraphQL schema and resolvers using
`graphene <https://graphene-python.org/>`__,
and expose them through a controller.
An example is available in the ``graphql_demo`` module.
