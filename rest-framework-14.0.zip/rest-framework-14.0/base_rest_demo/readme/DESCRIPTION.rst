Demo addon to illustrate how to develop self documented REST services thanks
to the **base_rest** addon.
