* Laurent Mignon <laurent.mignon@acsone.eu>
* `Tecnativa <https://www.tecnativa.com>`_:

    * Carlos Roca
