Example on how to create your own scenario.
