Integrate the Release of Operation based on Available to Promise with Sales. The Priority Date of Stock
Moves will be equal to the confirmation date of their sales order.
