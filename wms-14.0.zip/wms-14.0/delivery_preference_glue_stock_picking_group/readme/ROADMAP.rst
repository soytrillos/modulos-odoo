This is a glue module, so the question is.

Is it necessary or there is a bug some where than cause this ?

Maybe in the grouping done by the module `stock_picking_group_by_partner_by_carrier`
in the function `_merge_procurement_groups`
