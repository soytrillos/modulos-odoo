* Thierry Ducrest <thierry.ducrest@camptocamp.com>
* `Trobz <https://trobz.com>`_:
* Nguyen Hoang Hiep <hiepnh@trobz.com>
