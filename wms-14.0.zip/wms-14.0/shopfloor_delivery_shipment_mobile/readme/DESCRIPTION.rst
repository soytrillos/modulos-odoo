This module adds the front end part for the shopfloor scenario
for delivery shipment.
