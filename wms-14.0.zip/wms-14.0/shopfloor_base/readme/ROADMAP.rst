* improve documentation
* change shopfloor.scenario.key to selection? See comment in model
