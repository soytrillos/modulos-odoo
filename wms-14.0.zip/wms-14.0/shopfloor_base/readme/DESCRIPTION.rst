Shopfloor is a barcode scanner application.

This module provides REST APIs to support scenario. It needs a frontend
to consume the backend APIs and provide screens for users on barcode devices.
A default front-end application is provided by ``shopfloor_mobile_base``.
