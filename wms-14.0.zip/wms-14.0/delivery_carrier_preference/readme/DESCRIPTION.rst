This module allows to define preferred shipping methods in order to fine tune
the selection of proper delivery carrier from delivery operations according to
the quantity available to promise.

Moreover it provides the possibility to force the recomputation of preferred
delivery carrier on the release of operations for Delivery Orders.
