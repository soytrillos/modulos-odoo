This module allows archival of product attributes and product attribute values.
