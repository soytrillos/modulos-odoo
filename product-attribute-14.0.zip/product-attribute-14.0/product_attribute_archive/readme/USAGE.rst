Simply use the archive action on any product attribute.

The attribute is then no longer usable on new products.

Identical functionality on product attribute values.

Existing variants are unaffected, only new ones.
