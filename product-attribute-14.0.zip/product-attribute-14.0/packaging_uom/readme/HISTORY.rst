0.1 (2015-08-04)
~~~~~~~~~~~~~~~~

* rename packaging_extended to packaging_uom

10.0.1.0.0 (2017-03-09)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] packaging_uom, purchase_packaging, sale_packaging: Migrated to 10.0

11.0.1.0.0 (2018-08-28)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] packaging_uom: Migration to 11.0

12.0.1.0.0 (2019-05-27)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] packaging_uom: Migration to 12.0

13.0.1.0.0 (2020-02-13)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIG] packaging_uom: Migration to 13.0
