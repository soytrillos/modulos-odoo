The development of this module has been financially supported by:

* Akretion <https://akretion.com>
* La Base <https://labase.coop>
