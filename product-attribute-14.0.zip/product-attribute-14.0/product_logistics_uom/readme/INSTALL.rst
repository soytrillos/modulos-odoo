Be aware, that this module only change the UoM but not the value.

It's the same behavior as base Odoo when you change from Metric System to Imperial System.
