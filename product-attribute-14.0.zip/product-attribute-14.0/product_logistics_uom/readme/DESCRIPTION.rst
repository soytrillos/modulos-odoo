This module allows to choose an Unit Of Measure (UoM) for products weight and volume.
It can be set product per product for users in group_uom.

Without this module, you only have the choice between Kg or Lb(s) and m³ for all the products.

For some business cases, you need to express in more precise UoM than default ones like Liters
instead of M³.
