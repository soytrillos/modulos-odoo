from . import product_template
from . import res_config_settings
