Assign a value to the profile field in the product template form.
Then, all fields which depend on this profile will be set to the right value at once.

If you deselect the profile value, all these fields keep the same value and you can change them manually
(back to standard behavior).

Install **Product Profile Example** module to see a use case in action.

Profiles are also defined as search filter and group.
