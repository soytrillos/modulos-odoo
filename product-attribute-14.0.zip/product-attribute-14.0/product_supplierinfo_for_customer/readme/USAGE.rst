There's a new section on *Sales* tab of the product form called "Customers",
where you can define records for customers with the same structure of the
suppliers.

There's a new option on pricelist items that allows to get the prices from the
supplierinfo at the product form.
