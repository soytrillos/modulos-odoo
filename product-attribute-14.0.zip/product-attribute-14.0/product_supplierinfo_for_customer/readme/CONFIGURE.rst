For these prices to be used in sale prices calculations, you will have
to create a pricelist with a rule with option "Based on" with the value
"Partner Prices: Take the price from the customer info on the 'product form')".
