You can configure thresholds :

* Globally, for a company, in the Sale Settings. It will be used for all
  the products of the company.

* On product category form. It will be used for all the products of this
  category, or of the child categories. (User should be part of the new group
  'Stock State Threshold by Category'.)

* On product template form, for a specific product. (User should be part of
  the new group 'Stock State Threshold by Product'.)
