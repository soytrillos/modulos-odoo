from . import res_company
from . import res_config_settings
from . import product_category
from . import product_template
from . import product_product
