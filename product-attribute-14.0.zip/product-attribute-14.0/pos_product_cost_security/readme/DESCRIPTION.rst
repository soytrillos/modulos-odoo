This is a glue module to avoid permission errors when loading data in the Point of Sale
if the user has no ``standard_price`` (cost) field permissions.
