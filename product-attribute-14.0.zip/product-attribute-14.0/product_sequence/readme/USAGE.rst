To specify a different sequence for a product category proceed as follows:

#. Go to the a Product Category form view.
   (**note:** you will need to install Inventory app to be able to access to
   the form view, *Inventory > Configuration > Products > Products Categories*;
   or create a menuitem manually).
#. Fill the *Prefix for Product Internal Reference* as desired.
#. Under the settings (Settings -> General Settings -> Products), you can specify
   whether the prefix of the parent category should be used if no prefix has been
   specified for the category.

.. image:: https://odoo-community.org/website/image/ir.attachment/5784_f2813bd/datas
   :alt: Try me on Runbot
   :target: https://runbot.odoo-community.org/runbot/135/12.0
