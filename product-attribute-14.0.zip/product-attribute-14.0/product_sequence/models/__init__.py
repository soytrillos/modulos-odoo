from . import res_company
from . import res_config_settings
from . import ir_sequence
from . import product_product
from . import product_category
