* Benjamin Willig <benjamin.willig@acsone.eu>
* Numigi (tm) and all its contributors (https://bit.ly/numigiens)
* Patrick Wilson <patrickraymondwilson@gmail.com>
* Pimolnat Suntian <pimolnats@ecosoft.co.th>

* `Camptocamp <https://www.camptocamp.com>`_

  * Iván Todorovich <ivan.todorovich@gmail.com>
