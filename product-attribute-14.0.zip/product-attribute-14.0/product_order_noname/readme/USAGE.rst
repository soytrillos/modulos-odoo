Just by installing the module you should see a performance increase when retrieving products, from the website shop
or the product's list view for example.
