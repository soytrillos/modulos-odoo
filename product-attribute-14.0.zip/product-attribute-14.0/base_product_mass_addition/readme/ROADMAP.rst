Adding new implementations would be great:
on sale.order or on stock.picking.batch for instance.
