This module allows you to store the revision of a product and a BOM.
