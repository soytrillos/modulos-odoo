* Go to Inventory > Master Data > Products
* Create or edit a product.
* Enter the product revision and save.
* Create or edit a BOM.
* Enter the BOM revision and save.
