# Copyright 2019 C2i Change 2 improve - Eduardo Magdalena <emagdalena@c2i.es>

from . import product
from . import mrp
