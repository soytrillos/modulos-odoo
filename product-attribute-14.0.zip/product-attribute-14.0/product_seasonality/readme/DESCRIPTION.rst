Define rules for products' seasonal availability.
