Go to "Settings -> Companies" and configure the default seasonal configuration for a company.
Go to "Contacts -> Partner" and configure the seasonal configuration for the specific partner.

The configuration for products sale is available when `sale_product_seasonality` is installed.
