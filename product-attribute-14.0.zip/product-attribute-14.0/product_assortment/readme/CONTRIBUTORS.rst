* Denis Roussel <denis.roussel@acsone.eu>
* Cédric Pigeon <cedric.pigeon@acsone.eu>
* Xavier Bouquiaux <xavier.bouquiaux@acsone.eu>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Roca
