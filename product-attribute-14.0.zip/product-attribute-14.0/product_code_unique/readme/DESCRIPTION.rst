This module adds a constraint on the internal reference of the product
to make it unique across the database.
