Makes barcode field required, defaults it to product's code.
