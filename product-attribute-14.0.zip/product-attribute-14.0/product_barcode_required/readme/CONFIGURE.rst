Go to "Settings -> General -> Products" and enable "Product variant barcode required".
