To create a new packaging type:

#. Go to *Sales > Configuration > Products > Product Packaging Type*.
#. You can create/edit/delete packaging types
