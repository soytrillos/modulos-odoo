* Iryna Vyshnevska, Camptocamp
* `Trobz <https://trobz.com>`_:
  * Dung Tran <dungtd@trobz.com>
