This module allows to store dimensions (length, width, height), weight and
volume of product packagings.
