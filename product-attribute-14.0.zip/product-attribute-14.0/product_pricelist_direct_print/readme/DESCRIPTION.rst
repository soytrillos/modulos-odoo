Print price list from menu option, product templates, products variants or
price lists

*Note:* Odoo provides a similar feature, but with limited functionality.
