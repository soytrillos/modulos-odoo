* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden
  * David Vidal
  * Sergio Teruel
  * João Marques

* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>
