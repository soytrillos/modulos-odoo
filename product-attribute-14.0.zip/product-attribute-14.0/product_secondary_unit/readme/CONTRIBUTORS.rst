* Carlos Dauden <carlos.dauden@tecnativa.com>
* Sergio Teruel <sergio.teruel@tecnativa.com>
* Kitti Upariphutthiphong <kittiu@ecosoft.co.th>
* Pimolnat Suntian <pimolnats@ecosoft.co.th>
* Alan Ramos <alan.ramos@jarsa.com.mx>
