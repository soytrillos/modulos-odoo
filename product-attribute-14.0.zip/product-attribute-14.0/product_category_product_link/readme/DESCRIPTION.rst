This module is a technical module and adds link to products from a category
(only for direct link - not hierarchy)
