Before using this module, you must be familiar with the
server_environment module.
