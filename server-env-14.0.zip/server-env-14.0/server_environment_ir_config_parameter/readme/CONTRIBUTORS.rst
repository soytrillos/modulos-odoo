* Stéphane Bidoul <stephane.bidoul@acsone.eu> (https://acsone.eu)
* Thierry Ducrest <thierry.ducrest@camptocamp.com>
* Gilles Meyomesse <gilles.meyomesse@acsone.eu> (https://acsone.eu)
