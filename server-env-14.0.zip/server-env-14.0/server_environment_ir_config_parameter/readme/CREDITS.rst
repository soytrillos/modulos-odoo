This module is maintained by:
* Odoo Community Association
