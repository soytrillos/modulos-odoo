* it is not possible to set the environment from the command line. A
  configuration file must be used.
* the module does not allow to set low level attributes such as database server, etc.
* `server.env.techname.mixin`'s `tech_name` field could leverage the new option
  for computable / writable fields and get rid of some onchange / read / write code.
