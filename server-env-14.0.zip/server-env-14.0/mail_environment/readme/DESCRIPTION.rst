This module allows to configure the incoming and outgoing mail servers
using the `server_environment` mechanism: you can then have different
mail servers for the production and the test environment.
