For now the encryption is dependent on the environment. It has been designed
to store the same kind of data with different values depending on the environement
(dev, preprod, prod...).
An improvement could be to split this in 2 modules. But the environment stuff
is not a big constraint.
