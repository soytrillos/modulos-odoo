When installed, all remotes will be stored by `hostname` on `res.remote`.
They can be viewed on `Settings / Remotes`.
The last IP of the remote will be stored.
