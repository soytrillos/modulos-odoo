This module allows to store all the connected remotes (external ip addresses) to Odoo.
It should be used with other modules in order to check remote's configurations.
