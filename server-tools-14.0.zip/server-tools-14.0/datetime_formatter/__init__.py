# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).
from . import models

# Make these easily available for submodules
from .models.res_lang import MODE_DATE, MODE_DATETIME, MODE_TIME
