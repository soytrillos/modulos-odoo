* `Tecnativa <https://www.tecnativa.com>`_:

  * Jairo Llopis
  * Vicent Cubells
  * Ernesto Tejeda
  * Víctor Martínez
* Dhara Solanki <dhara.solanki@initos.com>
