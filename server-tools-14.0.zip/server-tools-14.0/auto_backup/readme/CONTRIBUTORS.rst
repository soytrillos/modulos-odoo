* Yenthe Van Ginneken <yenthe.vanginneken@vanroey.be>
* Alessio Gerace <alessio.gerace@agilebg.com>
* Jairo Llopis <yajo.sk8@gmail.com>
* Dave Lasley <dave@laslabs.com>
* Andrea Stirpe <a.stirpe@onestein.nl>
* Aitor Bouzas <aitor.bouzas@adaptivecity.com>
* Simone Vanin <simone.vanin@agilebg.com>
