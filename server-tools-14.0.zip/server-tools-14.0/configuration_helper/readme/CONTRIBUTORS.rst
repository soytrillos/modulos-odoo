* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* David BEAL <david.beal@akretion.com>
* Sébastien BEAU <sebastien.beau@akretion.com>
* Angel Moya <angel.moya@pesol.es>
* Akim Juillerat <akim.juillerat@camptocamp.com>
* Patrick Tombez <patrick.tombez@camptocamp.com>
* Phuc Tran Thanh <phuc@trobz.com>
* Helly kapatel <helly.kapatel@initos.com>
