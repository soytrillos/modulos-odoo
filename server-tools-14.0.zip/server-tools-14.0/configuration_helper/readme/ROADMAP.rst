  * support (or check support) for these field types : o2m, m2m, reference, property, selection
  * automatically generate a default view for 'res.config.settings' (in --debug ?)
