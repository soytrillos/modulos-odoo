This module was written to have your Odoo installation request SSL certificates
from https://letsencrypt.org automatically.
