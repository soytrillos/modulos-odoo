This module allows to log into the server the basic information of emails
that have been fetched from the mail server, before they start to be processed.

This allows for a better analysis of situations where emails are found to be
missing in Odoo. Can help to better resolve questions of the type 'Was it that
the email was never fetched, or a problem found when it was processed by
Odoo?'.
