* Raphaël Valyi <raphael.valyi@akretion.com>
* Renato Lima <renato.lima@akretion.com>
* Sébastien BEAU <sebastien.beau@akretion.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* SodexisTeam <dev@sodexis.com>
* Mourad EL HADJ MIMOUNE <mourad.elhadj.mimoune@akretion.com>
* Raphaël Reverdy <raphael.reverdy@akretion.com>
* Iván Todorovich <ivan.todorovich@druidoo.io>

* Tecnativa <tecnativa.com>

  * João Marques

* Kevin Khao <kevin.khao@akretion.com>
