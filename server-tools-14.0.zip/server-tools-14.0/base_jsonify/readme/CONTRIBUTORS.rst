* BEAU Sébastien <sebastien.beau@akretion.com>
* Raphaël Reverdy <raphael.reverdy@akretion.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Nans Lefebvre <nans.lefebvre@acsone.eu>
