* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Alex Comba <alex.comba@agilebg.com>
* Akim Juillerat <akim.juillerat@camptocamp.com>
