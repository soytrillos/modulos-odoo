This module extends the functionality of base_kanban_stage to allow you to
map stages from base_kanban_stage to states. The states are:

* New (draft)
* In Progress (open)
* Pending (pending)
* Done (done)
* Cancelled (cancelled)
* Exception (exception)
