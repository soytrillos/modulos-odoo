This module includes a method that extracts image URLs from any chunk of HTML,
in appearing order.

It is useful for modules such as `website_blog_excerpt_img
<https://github.com/OCA/website/tree/14.0/website_blog_excerpt_img>`_: blog list shows the first
image included in the post if haven't a defined cover image.
