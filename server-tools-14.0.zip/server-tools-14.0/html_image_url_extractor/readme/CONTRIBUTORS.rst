* Dennis Sluijk <d.sluijk@onestein.nl>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Jairo Llopis
  * Vicent Cubells
  * Cristina Martin R
  * Víctor Martínezz

* Helly kapatel <helly.kapatel@initos.com>
