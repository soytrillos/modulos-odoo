This module allow to store list in Serialized.
This is a technical module
