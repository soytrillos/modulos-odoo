This module provide some example use case for excel_import_export

1. Import/Export Sales Order (import_export_sale_order)
2. Import New Sales Orders (import_sale_orders)
3. Sales Orders Report (report_sale_order)
4. Print Quoation / Order (.xlsx) (report_action/sale_order)
5. Run Partner List Report (report_action/partner_list)
