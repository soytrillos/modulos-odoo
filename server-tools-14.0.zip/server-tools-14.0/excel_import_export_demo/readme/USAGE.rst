**Example 1:** Export/Import Excel on existing document

To test this use case, go to any Sales Order and use Export Excel or Import Excel in action menu.

**Example 2:** Import Excel Files

To test this use case, go to Settings > Excel Import/Export > Sample Import Sales Order

**Example 3:** Create Excel Report

To test this use case, go to Settings > Excel Import/Export > Sample Sales Report

**Example 4:** Printout Excel on existing document, using report action

To test this use case, go to any Sales Order and click print "Quotation / Order (.xlsx)".

**Example 5:** Run Partner List Report, using report action

To test this use case, go to menu Sales > Reporting > Partner List Report
