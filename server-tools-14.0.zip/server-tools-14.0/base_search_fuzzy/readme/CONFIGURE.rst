If the odoo module is installed:

#. You can define ``GIN`` and ``GiST`` indexes for `char` and `text` via
   `Settings -> Database Structure -> Trigram Index`. The index name will
   automatically created for new entries.
