This addon provides the ability to create GIN or GiST indexes of char and text
fields and also to use the search operator `%` in search domains. Currently
this module doesn't change the backend search or anything else. It provides
only the possibility to perform the fuzzy search for external addons.
