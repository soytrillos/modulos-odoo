* Christoph Giesel <https://github.com/christophlsa>
* Jordi Ballester <jordi.ballester@forgeflow.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Dave Lasley <dave@laslabs.com>

* `Tecnativa <https://www.tecnativa.com>`_:
  * Vicent Cubells
  * Ernesto Tejeda
* teodoralexandru@nexterp.ro  2020            NextERP SRL.
