This module extends the functionality of scheduled actions to allow you to
select the ones that should not run simultaneously.
