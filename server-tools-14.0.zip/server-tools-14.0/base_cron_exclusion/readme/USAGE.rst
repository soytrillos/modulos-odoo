To use this module, you need to:

#. Go to *Settings > Technical > Automation > Scheduled Actions*.
#. In the form view go to the tab *Mutually Exclusive Scheduled Actions*.
#. Fill it with the actions that should be blocked while running the action
   you are editing. Note that this is mutual and the selected actions will
   block the initial action when running.
