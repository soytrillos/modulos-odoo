This module changes the way the weight is computed on move, operation and
package to include packaging weight instead of the weight of the product only.
