* Camptocamp:
  * Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
  * Thierry Ducrest <thierry.ducrest@camptocamp.com>
* BCIM:
  * Jacques-Etienne Baudoux <je@bcim.be>

* Phuc Tran Thanh <phuc@trobz.com>
