This module allows to define a Default shipping weight on Delivery packages
(`product.packaging`) in order to set automatically the Shipping weight on the
packages (`stock.quant.package`) using this Package type.
