Just open a cancelled picking and click on 'back to draft' button
