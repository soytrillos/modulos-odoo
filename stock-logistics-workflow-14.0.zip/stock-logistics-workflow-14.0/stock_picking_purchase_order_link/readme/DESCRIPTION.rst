This module extends standard WMS to add a smart button in pickings to go to
purchase order that creates the picking.
