To use this module, you need to:

#. Go to *Sales > Products* and create one of type "Stockable".
#. Go to *Sales > Sales Orders*, create one and confirm.
#. Go to the picking generated clicking in Delivery smart button.
#. In the picking form there will be a new *Sales Order* smart button
   to navigate to the related Sales Order.
