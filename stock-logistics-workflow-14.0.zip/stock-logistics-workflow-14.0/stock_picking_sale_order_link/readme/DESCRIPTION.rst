This module adds a smart button to Stock Transfers,
to open the related Sales Order.
