To allow a user to block or unblock a Lot:

#. Open the user settings (menu "Settings > Users & Companies > Users")
#. In the "Warehouse" section, check the box
   "Allow to block/unblock Serial Numbers/Lots"

To allow move locked lots to a location:
#. Open the locations (menu "Inventory > Configuration > Warehouse Management > Locations")
#. check the box "Allow Locked"
