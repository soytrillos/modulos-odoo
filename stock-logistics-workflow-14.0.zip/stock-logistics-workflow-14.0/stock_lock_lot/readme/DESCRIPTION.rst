This module allows you to define whether a Serial Number/lot is blocked
or not.
The default value can be set on the Product Category, in the
field "Block new Serial Numbers/lots".
Is possible to specify in a location if locked lots are allowed to move there.
