To use this module, you need to:

#. Go to *Inventory > Master Data > Lots/Serial Numbers*
#. Select one 'Lot/Serial Number' and check 'Blocked' field
#. Now you cannot move that 'Lot/Serial Number' to any location that does
   not have the 'Allow Locked' field checked
