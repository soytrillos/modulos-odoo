* Ana Juaristi <anajuaristi@avanzosc.es>
* Alfredo de la Fuente <alfredodelafuente@avanzosc.es>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Lionel Sausin <ls@numerigraphe.com>
* Ainara Galdona <ainaragaldona@avanzosc.es>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Ernesto Tejeda
