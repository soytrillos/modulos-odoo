Inherit from this module and override `stock.move._domain_search_picking_for_assignation`
to modify the domain used to search for pickings.
