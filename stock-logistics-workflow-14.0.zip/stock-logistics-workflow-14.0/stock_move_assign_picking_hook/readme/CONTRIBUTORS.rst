* Camptocamp:
  * Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* BCIM:
  * Jacques-Etienne Baudoux <je@bcim.be>

* Simone Orsi <simahawk@gmail.com>
* Phuc Tran Thanh <phuc@trobz.com>
