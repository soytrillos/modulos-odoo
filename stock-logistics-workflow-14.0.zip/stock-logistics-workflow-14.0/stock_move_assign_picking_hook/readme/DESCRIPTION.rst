Tecnical module that allows to override the assignation of pickings to moves.
