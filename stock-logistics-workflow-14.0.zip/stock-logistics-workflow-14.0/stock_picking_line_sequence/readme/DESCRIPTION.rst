
Provide a new field sequence on stock moves, which allows to manage the order of moves in a picking.

For further information, please visit:

* https://www.odoo.com/forum/help-1
