
* Cécile Jallais <cjallais@archeti.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Damien Crier <damien.crier@camptocamp.com>
* Eficent Business and IT Consulting Services S.L. <contact@eficent.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
