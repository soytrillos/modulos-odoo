To configure this module, you need to:

* Set the flag "Automatic" on stock rule.
