To install this module, you need to:

* Click on install button
