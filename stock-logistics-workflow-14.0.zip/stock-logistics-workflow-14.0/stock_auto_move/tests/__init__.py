from . import test_stock_auto_move
