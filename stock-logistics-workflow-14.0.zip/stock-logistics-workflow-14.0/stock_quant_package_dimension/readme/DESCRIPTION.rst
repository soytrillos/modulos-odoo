This module adds dimension fields on stock packages
and an estimated weight (in kg).
