Your preferred way to install addons will work with Stock Picking Backorder Strategy.

An easy way to install it with all its dependencies is using pip:

pip install --pre odoo11-addon-stock-picking-backorder-strategy
then restart Odoo, update the addons list in your database, and install the Stock Picking Backorder Strategy application.
