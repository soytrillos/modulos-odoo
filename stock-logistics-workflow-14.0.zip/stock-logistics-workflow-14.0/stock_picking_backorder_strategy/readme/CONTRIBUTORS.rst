* Laetitia Gangloff <laetitia.gangloff@acsone.eu>
* Denis Roussel <denis.roussel@acsone.eu>
* Mayank Gosai <mgosai@opensourceintegrators.com>
* Luis Escobar <lescobar@vauxoo.com>
* Rujia Liu <rujial@roof.co.nz>
