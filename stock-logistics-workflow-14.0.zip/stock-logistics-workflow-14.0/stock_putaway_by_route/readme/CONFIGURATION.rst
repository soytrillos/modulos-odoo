Go to Inventory > Configuration > Putaway Rules (the "Storage Locations" setting must be active).
Create a new rule, a route can be selected.
