This module add a field to restrict a stock move to a specific lot.
It propagates it between chained moves. A move with a restrict lot will only be able to
reserve or transfer products with the specified lot.
This module is a based for other modules, it has not effect on its own.
