* Do not rely on original MTO record and have something configurable instead.
