To configure this module, you need to:

* Go to **Inventory -> Configuration -> Stock Picking Cancel Reason.**
