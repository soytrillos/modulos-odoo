This module is similar to purchase_cancel_reason, but for stock picking

* During stock picking state equal to assigned,confirmed,partially_available,draft,waiting
* Click at "Cancel" button, a wizard will show a list of cancel reasons
* Choose a reason and confirm cancellation, the reason will be stamped in the stock picking
