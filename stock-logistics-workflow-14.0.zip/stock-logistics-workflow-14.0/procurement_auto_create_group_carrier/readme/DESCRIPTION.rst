This module is the glue between `procurement_auto_create_group` and `stock_picking_group_by_partner_by_carrier`.
It stores the delivery carrier id into the procurement group.
