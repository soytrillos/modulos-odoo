* Camptocamp:
    * Thierry Ducrest <thierry.ducrest@camptocamp.com>
* `Trobz <https://trobz.com>`_:
    * Hai Lang <hailn@trobz.com>
