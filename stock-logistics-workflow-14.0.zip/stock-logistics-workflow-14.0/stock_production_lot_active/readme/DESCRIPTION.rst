Allow to archive/unarchive a lot.
