* `Tecnativa <https://www.tecnativa.com>`_:

  * Sergio Teruel
  * Pedro M. Baeza
  * David Vidal

* `Pro Thai <http://prothaitechnology.com>`__:

  * Prapassorn Sornkaew <prapassorn.s@prothaitechnology.com>
