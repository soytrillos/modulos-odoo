This module allows to return stock from a location to either suppliers,
customers or internal locations reverting the corresponding pickings.
