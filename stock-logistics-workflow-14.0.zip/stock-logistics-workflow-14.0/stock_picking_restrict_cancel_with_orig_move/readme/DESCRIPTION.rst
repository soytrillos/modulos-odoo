This module restricts the cancellation of stock picking, if any move is linked
to a previous move, which is not canceled or done yet.
