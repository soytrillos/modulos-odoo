* `Agile Business Group <https://www.agilebg.com>`_

  * Lorenzo Battistini <lorenzo.battistini@agilebg.com>
  * Alex Comba <alex.comba@agilebg.com>

* `Akretion <https://www.akretion.com>`_

  * Alexis de Lattre <alexis.delattre@akretion.com>

* `AvanzOsc <http://avanzosc.es>`_

  * Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
  * Ana Juaristi <anajuaristi@avanzosc.es>
  * Alfredo de la Fuente <alfredodelafuente@avanzosc.es>
  * Ainara Galdona <ainaragaldona@avanzosc.es>

* `Tecnativa <https://www.tecnativa.com>`_

  * Pedro M. Baeza
  * David Vidal
  * Sergio Teruel
  * João Marques

* Unai Alkorta
* Iñaki Zabala
* Jacques-Etienne Baudoux <je@bcim.be>
* Aitor Bouzas Naveira <abouzas@softdil.com>
* Carlos Lopez Mite <celm1990@gmail.com>
