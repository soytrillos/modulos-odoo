* `Tecnativa <https://www.tecnativa.com>`_:

    * Pedro M. Baeza <pedro.baeza@tecnativa.com>
    * Sergio Teruel <sergio.teruel@tecnativa.com>

* `BizzAppDev <https://www.bizzappdev.com>`_:

    * Shruti Singh <shruti.singh@bizzappdev.com>
    * Ruchir Shukla <ruchir@bizzappdev.com>
