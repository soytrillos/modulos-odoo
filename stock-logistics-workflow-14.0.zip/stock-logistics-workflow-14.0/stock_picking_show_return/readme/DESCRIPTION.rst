This module adds one tab in the pickings form view to display the returns
pickings related to the current one.
