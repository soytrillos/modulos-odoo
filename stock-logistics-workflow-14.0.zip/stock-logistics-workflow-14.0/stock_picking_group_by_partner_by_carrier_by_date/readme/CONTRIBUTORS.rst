* Simone Orsi <simahawk@gmail.com>

* Camptocamp:
  * Joël Grand-Guillaume <joel.grandguillaume@camptocamp.com>

* Phuc Tran Thanh <phuc@trobz.com>
