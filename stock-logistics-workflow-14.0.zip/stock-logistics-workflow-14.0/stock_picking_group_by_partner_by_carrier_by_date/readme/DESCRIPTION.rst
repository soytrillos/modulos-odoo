Group delivery orders by partner, carrier and scheduled date.
